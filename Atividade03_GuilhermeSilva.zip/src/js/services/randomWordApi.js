const RANDOM_WORD_API_URL = "https://random-word-api.herokuapp.com";

async function fetchRandomWords(number) {
  if (isNaN(parseInt(number))) {
    throw new TypeError(`${number} is NaN`);
  }

  if (parseInt(number) <= 0) {
    return [];
  }

  const response = await fetch(RANDOM_WORD_API_URL + `/word?number=${number}`);
  const words = await response.json();

  return words;
}

export { fetchRandomWords };
