# Let's Code - Module 02 - Project 01

## Description

Simple hangman game using HTML, CSS and JS.

## How To

Serve the content of the `src` folder using a local web-server
such as, for instance, VSCode's **Live Server** or **Live Preview**
extensions.

## Author

Guilherme Tavares da Silva (<guilherme.tsilva@gmail.com>)
