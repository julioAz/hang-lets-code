import { Word } from "../models/Word.js";
import { Web } from "../views/Web.js";

export class HangmanGame {
  constructor(config) {
    this.config = config;

    this.word = new Word(this.config);
    this.view = new Web(this.config);

    this.view.displayKeyboard();

    this.view.btnPlay.addEventListener("click", async (event) => {
      event.preventDefault();
      await this.handlePlay();
    });

    this.view.btnPlayAgain.addEventListener("click", async (event) => {
      event.preventDefault();
      await this.handlePlay();
    });

    this.view.gameKeys.forEach((key) => {
      key.addEventListener("click", (event) => {
        event.preventDefault();
        this.handleKeyGuess(key);
      });
    });
  }

  async handlePlay() {
    this.resetGame();

    await this.word.fetch();

    this.view.displayWord(this.word);
    this.view.displayGuesses(this.config.gameMaxGuesses);
    this.view.displayGame();
  }

  handleKeyGuess(key) {
    const letterGuessed = key.innerHTML;
    key.disabled = true;

    let guessed = false;
    this.word.letters.forEach((letter) => {
      if (letter.char === letterGuessed) {
        guessed = true;
        letter.isGuessed = true;
      }
    });

    if (!guessed) {
      this.guessesRemaining--;
    }

    this.evaluateGame();

    this.view.displayWord(this.word);
    this.view.displayGuesses(this.guessesRemaining);
  }

  evaluateGame() {
    // Lost - No more guesses remaining
    if (this.guessesRemaining <= 0) {
      this.view.displayResult(false, this.word.literal);
    }

    // Check if all letters were guessed
    let won = true;
    this.word.letters.forEach((letter) => {
      if (!letter.isGuessed) {
        won = false;
      }
    });

    // Won
    if (won) {
      this.view.displayResult(true, this.word.literal);
    }
  }

  resetGame() {
    this.guessesRemaining = this.config.gameMaxGuesses;
    this.view.clearKeyboard();
  }
}
