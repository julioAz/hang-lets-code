export class Web {
  constructor({ wordAlphabet }) {
    this.wordAlphabet = wordAlphabet;

    this.btnPlay = document.querySelector("#btnPlay");
    this.btnPlayAgain = document.querySelector("#btnPlayAgain");

    this.frameStart = document.querySelector(".frame--start");
    this.frameGame = document.querySelector(".frame--game");
    this.frameEnd = document.querySelector(".frame--end");
    this.frameEndResult = document.querySelector("#frameEndResult");
    this.frameEndCorrectWord = document.querySelector(".frame__correctWord");

    this.gameWord = document.querySelector(".game__word");
    this.gameKeyboard = document.querySelector(".game__keyboard");
    this.gameGuesses = document.querySelector("#gameGuesses");
    this.gameKeys = [];
  }

  displayGame() {
    this.frameStart.style.display = "none";
    this.frameEnd.style.display = "none";
    this.frameGame.style.display = "flex";
  }

  clearResult() {
    this.frameEndResult.innerHTML = "";
    this.frameEndResult.classList.remove(...this.frameEndResult.classList);
  }

  displayResult(won, wordLiteral) {
    this.clearResult();

    if (won) {
      this.frameEndResult.innerHTML = "You Won!";
      this.frameEndResult.classList.add("game__result", "game__result--won");
    } else {
      this.frameEndResult.innerHTML = "You Lost.";
      this.frameEndResult.classList.add("game__result", "game__result--lost");
    }

    this.frameEndCorrectWord.innerHTML = wordLiteral;

    this.frameStart.style.display = "none";
    this.frameGame.style.display = "none";
    this.frameEnd.style.display = "flex";
  }

  displayGuesses(guessesRemaining) {
    const HEART = "&hearts;";

    let hearts = "";
    for (let i = 0; i < guessesRemaining; ++i) {
      hearts += HEART;
    }

    this.gameGuesses.innerHTML = hearts;
  }

  clearKeyboard() {
    this.gameKeys.forEach((key) => {
      key.disabled = false;
    });
  }

  displayKeyboard() {
    this.clearKeyboard();

    Array.from(this.wordAlphabet).forEach((letter) => {
      const button = document.createElement("button");
      button.classList.add("btn", "game__key");
      button.innerHTML = letter;

      this.gameKeyboard.appendChild(button);
      this.gameKeys.push(button);
    });
  }

  clearWord() {
    this.gameWord.innerHTML = "";
  }

  displayWord(word) {
    this.clearWord();

    word.letters.forEach((letter) => {
      const li = document.createElement("li");
      li.classList.add("game__letter");

      if (letter.isGuessed) {
        li.innerHTML = letter.char;
      }

      this.gameWord.appendChild(li);
    });
  }
}
