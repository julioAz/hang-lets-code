import { sleep } from "../helpers/sleep.js";
import { fetchRandomWords } from "../services/randomWordApi.js";

export class Word {
  constructor({
    wordAlphabet,
    wordMinLength,
    wordMaxLength,
    wordMaxFetchAttempts,
    wordFetchAttemptsDelay,
  }) {
    this.wordAlphabet = wordAlphabet;
    this.wordMinLength = wordMinLength;
    this.wordMaxLength = wordMaxLength;
    this.wordMaxFetchAttempts = wordMaxFetchAttempts;
    this.wordFetchAttemptsDelay = wordFetchAttemptsDelay;
  }

  // Attempts to fetch a word using the `fetchRandomWords` function
  // derived from the Random Word API service. `wordMaxFetchAttempts` attempts
  // are performed, sleeping `wordFetchAttempsDelay` (miliseconds) between
  // each attempt.
  async fetch() {
    let wordFetched;

    for (let attempt = 0; attempt < this.wordMaxFetchAttempts; ++attempt) {
      const words = await fetchRandomWords(10);
      const validatedWords = words.filter((word) => this.#validate(word));

      if (validatedWords.length > 0) {
        wordFetched = validatedWords[0];
        break;
      }

      await sleep(this.wordFetchAttemptsDelay);
    }

    if (!wordFetched) {
      throw new Error("Unable to fetch word");
    }

    this.#save(wordFetched.toUpperCase());
  }

  #validate(word) {
    if (word.length < this.wordMinLength) {
      return false;
    }

    if (word.length > this.wordMaxLength) {
      return false;
    }

    for (let letter of word.toUpperCase()) {
      if (!this.wordAlphabet.includes(letter)) {
        return false;
      }
    }

    return true;
  }

  #save(word) {
    this.literal = word;

    this.letters = Array.from(word).map((letter) => {
      return {
        char: letter,
        isGuessed: false,
      };
    });
  }
}
