import { HangmanGame } from "./controllers/HangmanGame.js";

const config = {
  gameMaxGuesses: 6,
  wordAlphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  wordMinLength: 5,
  wordMaxLength: 10,
  wordMaxFetchAttempts: 5,
  wordFetchAttempsDelay: 200,
};

new HangmanGame(config);
